
exports.corsOptions = {
    origin: true, 
    credentials: true,
    optionsSuccessstatus:200,
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE'
} 
